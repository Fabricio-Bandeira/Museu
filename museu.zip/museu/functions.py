import os
import time
artistas = []
def criar_conta(usuarios):
    print("-"*25)
    print(f'{"Tela de Cadastro":^25}')
    print("-"*25)
    login = input("Digite o seu login: ")
    senha = input("Digite a senha: ")
    usuarios.append({"login": login, "senha": senha, "acesso": "comum"},)

def validar_login(usuarios):
    while True: 
        print("-"*25)
        print(f'{"Tela de Login":^25}')
        print("-"*25)
        login = input('Login: ')
        senha = input('Senha: ')
            
        usuario_encontrado = False
        for item in usuarios:
            if login == item["login"]:
                usuario_encontrado = True
                if senha == item["senha"]:
                    os.system("cls")
                    return item["acesso"]
                else:
                    print('Senha incorreta!')
                    time.sleep(2)
                    os.system("cls")
                    break
            
        if usuario_encontrado == False:
            print('Usuário incorreto.')
            time.sleep(2)
            os.system("cls")



def quick_sort(lista):
    if len(lista) <= 1:
        return lista
    else:
        pivot = lista.pop()

    elementos_maiores = []
    elementos_menores = []

    for elemento in lista:
        if elemento > pivot:
            elementos_maiores.append(elemento)
        else:
            elementos_menores.append(elemento)
    return quick_sort(elementos_menores) + [pivot] + quick_sort(elementos_maiores)



def busca_binaria(lista, busca):
    inicio, fim = 0, len(lista)-1

    while inicio <= fim:
        meio = (inicio+fim)//2

        if lista[meio] == busca:
            return meio
        elif lista[meio] < busca:
            inicio = meio + 1
        else:
            fim = meio - 1            
    
    return -1




def cadastrar_usuario(usuarios):
    while True:
        print("-"*25)
        print(f'{"Cadastro de usuários":^25}')
        print("-"*25)

        login = input("login: ")
        senha = input("Senha: ")
        acesso = input("Acesso: ")

        for user in usuarios:
            if login == user["login"]:
                print('Usuario já existente.')
                continue

        usuarios.append({"login":login, "senha":senha, "acesso":acesso})
        print('Usuário cadastrado!')
    
        break

def cadastrar_artista(artistas):
    while True:
        print("-"*25)
        print(f'{"Cadastro de artistas":^25}')
        print("-"*25)

        nome = input("Nome do Artista: ")
        data = input("data de Nascimento:  ")
        local = input("Local de nascimento:  ")
        biografia = input("Biografia do Artista: ")
        estilo = input("Estilo do Artista: ")
        obras = []
        obras_artista = input("Digite o nome da obra desse artista: ")
        obras.append(obras_artista)

        for artista in artistas:                      
            if nome == artista["nome"]:
                print('Usuario já existente.')
                continue

        artistas.append({"nome":nome, "data":data, "local":local, "biografia":biografia, "estilo":estilo})
        print('Artista cadastrado!')
        break



def gerenciar_usuarios(usuarios):
    while True:
        print("\n1 - Cadastrar Usuários")
        print("2 - Cadastrar Artista")
        print("3 - Deletar Usuários")
        print("4 - Listar Usuários")
        print("5 - Voltar ao início")

        selecao = input("Selecione uma das opções acima: ")

        try:
            int(selecao)
            if int(selecao) > 5:
                print('Digite somente as opções válidas.')
                continue

        except ValueError:
            print('Digite somente as opções validas.')
            continue
        
        if selecao == "1":
            cadastrar_usuario(usuarios)
        elif selecao == "2":
            cadastrar_artista(artistas)

        elif selecao == "3":
            deletar = input("\nDigite o usuário que deseja deletar: ")
           

            for usuario in usuarios:
                if deletar == usuario["login"]:
                    usuarios.remove(usuario)
                    print("Usuário deletado.")
                    break
                

        elif selecao == "4":
            print("\nLista de Usuários:")
            for usuario in usuarios:
                print(usuario["login"], usuario["acesso"])

        elif selecao == "5":
            break