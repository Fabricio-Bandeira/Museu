import functions


usuarios = [
    {"login": "admin", "senha": "admin", "acesso": "administrador"},
    {"login": "fabricio", "senha": "1000", "acesso": "administrador"},
    {"login": "mamão", "senha": "tiktok", "acesso": "comum"},
]
with open("Caravaggio.txt", "r", encoding="utf-8") as arquivo:
    caravaggio = arquivo.read()
with open("Michelangelo.txt","r", encoding="utf-8") as arquivo:
    michelangelo = arquivo.read()

artistas = [
    {"nome": "Michelangelo", "data": "06/03/1475", "local": "Italia", "biografia": michelangelo, "estilo": "Renascentismo", "obras": ["Madonna da Escada", "Batalha dos Centauros"]},
    {"nome": "Caravaggio", "data": "29/09/1571", "local": "Italia", "biografia": caravaggio, "estilo": "Barroco", "obras": ["Baco", "Medusa","Os trapaceiros"]}
]

incursoes = [
    {"escola": "Oliveira", "quantidade": "30", "tema": "renascentismo", "roteiro": "neo-renascentismo", "data": "10/08"},
    {"escola": "Ciep", "quantidade": "30", "tema": "renascentismo", "roteiro": "neo-renascentismo", "data": "20/08"}
]


obras_reservadas = []

def main():
    print("-"*25)
    print(f'{"Tela Inicial":^25}')
    print("-"*25)
    while True:
        inicio = input("1- Fazer Login \n2- Se Cadastrar \nEscolha: ")
        if inicio == "1":
            break
        elif inicio == "2":
            cadastro = functions.criar_conta(usuarios)
        else:
            print("Escolha uma opção válida.")
    print(usuarios)
    
    validation = functions.validar_login(usuarios) 
    while True:
        if validation == "administrador":
            while True: 
                print('')
                print("-"*25)
                print(f'{"Museu Virtual:":^25} ')
                print("-"*25)    
                print("1 - Pesquisar Obras")
                print("2 - Reservas")
                print("3 - Incursões")
                print("4- Verificar incursões")
                print("5 - Gerenciar Usuarios")
                print("6 - Sair")

                selecao = input("Selecione uma das opções acima: ")
                try: 
                    int(selecao)
                    if int(selecao) > 5: 
                        print("Digite somente as opções validas.")
                        continue
                except ValueError:
                    print('digite somente as opções validas.')
                    continue
                if selecao == "1":
                    print("-"*25)
                    print(f"{"Pesquisar Obras":^25}")
                    print("-"*25)

                    obras = []
                    
                    for artista in artistas:
                        for obra in artista["obras"]:
                            obras.append(obra) 

                    obras_sort = functions.quick_sort(obras)
                    artistas_list = []
                    
                    for artista in artistas:
                        artistas_list.append(artista["nome"])
                    while True:
                        pesquisa = int(input("1- Pesquisar por título \n2- Pesquisar por Artista \nResposta:  "))
                        if pesquisa == 1:
                            busca = input("Digite o título da obra: ").capitalize()
                            print(busca)
                            disponibilidade = functions.busca_binaria(obras_sort, busca)

                            if disponibilidade == -1: 
                                print("Obra não encontrada!")
                                continue

                            else:
                                reservar = input("A Obra foi encontrada. Deseja reserva-la? [S/N] ").lower()
                                if reservar == "s": 
                                    obras_reservadas.append(busca)
                                    print("\nObra Reservada!")
                                    break
                        elif pesquisa == 2:
                            artistas_sort = functions.quick_sort(artistas_list)
                            print(artistas_sort)

                            busca_artista = input("Qual artista você deseja buscar? ").capitalize()
                            artista_encontrado = None
                            
                            for artista in artistas:
                                if artista["nome"] == busca_artista:
                                    artista_encontrado = artista
                                    

                            if artista_encontrado:
                                for item, valor in artista_encontrado.items():
                                    print(f"{item}: {valor}")
                            else: 
                                print("Artista não encontrado!")
                        else:
                            print("escolha uma opção válida")
                                
                            

                           

                elif selecao == "2":
                    print("-"*25)
                    print(f"{"Obras Reservadas:":^25}")
                    print("-"*25)
                    for Obras in obras_reservadas:
                        print("-",Obras)
                    print('''''')
 
                elif selecao == "3":
                    print("-"*25)
                    print(f"{"Marcar Incursão:":^25}")
                    print("-"*25)
                    
                    escola = input("Nome da escola: ")
                    quantidade = input("Quantidade de pessoas que participarão da incursão: ")
                    tema = input("Digite o tema que deseja ser incursado: ")
                    data = input("Digite a data da incursão: ")
                    
                    incursoes.append({"escola":escola, "quantidade":quantidade, "tema":tema, "data":data})
                    print("Incursão marcada!!")
                
                elif selecao == "4":

                    busca_incursao = input("Qual escola você deseja buscar? ").capitalize()
                    incursao_encontrado = None
                            
                    for incursao in incursoes:
                        if incursao["escola"] == busca_incursao:
                            incursao_encontrado = incursao
                            break
                                    

                    if incursao_encontrado:
                        for item, valor in incursao_encontrado.items():
                            print(f"{item}: {valor}")
                    else: 
                        print("incursao não encontrado!")
                       

                elif selecao == "5":
                    functions.gerenciar_usuarios(usuarios)

                elif selecao == "6":
                    break 
            break   
        else:
            while True:
                print("-"*25)
                print(f'{"Museu Virtual:":^25} ')
                print("-"*25)
                print("1 - Pesquisar Obras")
                print("2 - Obras Reservados")
                print("3 - Marcar Incursão")
                print("4 - Sair\n")

                selecao = input("Selecione uma das opções acima: ")
                
                if selecao == "1":
                    print("-"*25)
                    print(f"{"Pesquisar Obras":^25}")
                    print("-"*25)

                    obras = []
                    
                    for artista in artistas:
                        for obra in artista["obras"]:
                            obras.append(obra) 

                    obras_sort = functions.quick_sort(obras)
                    artistas_list = []
                    
                    for artista in artistas:
                        artistas_list.append(artista["nome"])
                    while True:
                        pesquisa = int(input("1- Pesquisar por título \n2- Pesquisar por Artista \nResposta:  "))
                        print(obras_sort)
                        if pesquisa == 1:
                            busca = input("Digite o título da obra: ").capitalize()
                            print(busca)
                            disponibilidade = functions.busca_binaria(obras_sort, busca)

                            if disponibilidade == -1: 
                                print("Obra não encontrada!")
                                continue

                            else:
                                reservar = input("A Obra foi encontrada. Deseja reserva-la? [S/N] ").lower()
                                if reservar == "s": 
                                    obras_reservadas.append(busca)
                                    print("\nObra Reservada!")
                                    break
                        elif pesquisa == 2:
                            artistas_sort = functions.quick_sort(artistas_list)
                            print(artistas_sort)

                            busca_artista = input("Qual artista você deseja buscar? ").capitalize()
                            artista_encontrado = None
                            
                            for artista in artistas:
                                if artista["nome"] == busca_artista:
                                    artista_encontrado = artista
                                    

                            if artista_encontrado:
                                for item, valor in artista_encontrado.items():
                                    print(f"{item}: {valor}")
                            else: 
                                print("Artista não encontrado!")
                        else:
                            print("escolha uma opção válida")
                
                elif selecao == "2":
                    print("-"*25)
                    print(f'{"Obras Reservados:":^25}')
                    print("-"*25)
                    for Obras in obras_reservadas:
                        print('-',Obras)

                elif selecao == "3":
                    print("-"*25)
                    print(f"{"Marcar Incursão:":^25}")
                    print("-"*25)
                    
                    escola = input("Nome da escola: ")
                    quantidade = input("Quantidade de pessoas que participarão da incursão: ")
                    tema = input("Digite o tema que deseja ser incursado: ")
                    data = input("Digite a data da incursão: ")
                    
                    incursoes.append({"escola":escola, "quantidade":quantidade, "tema":tema, "data":data})
                    print("Incursão marcada!!")
                elif selecao == "4":
                    break            
                        



if __name__ == "__main__":
    main()
